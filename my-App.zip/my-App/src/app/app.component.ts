import { Component, ViewChild,OnInit } from '@angular/core';
import { NgxCsvParser,NgxCSVParserError } from 'ngx-csv-parser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  {    //implements OnInit
  title= 'my-App'
  csvRecords: any[] = [];
  header = false;
  filterNum : Number;
 
  constructor(private ngxCsvParser: NgxCsvParser,) {}
 
  @ViewChild('fileImportInput', { static: false }) fileImportInput: any;
 
  // Your applications input change listener for the CSV File
  fileChangeListener($event: any): void {

    // Select the files from the event
    const files = $event.srcElement.files;
    // Parse the file you want to select for the operation along with the configuration
    this.ngxCsvParser.parse(files[0], { header: this.header, delimiter: ',' })

      .pipe().subscribe((result: Array<any>) => {
 
        console.log('Result', result);
        this.csvRecords = result;
      }, (error: NgxCSVParserError) => {
        console.log('Error', error);
      }
      );

  }

   
      
  
//find min max 

  minnmaxfinder() {
   // let value= null;      // operator use !=
   let fnum = this.filterNum; 
   
    // min and max of all objects
    let minVA1 = null; let maxVA1 = null;
    let minVM1 = null; let maxVM1 = null;
    let minSigma1 = null; let maxSigma1 = null;
    let minPM1 = null; let maxPM1 = null;
    let minVA2 = null; let maxVA2 = null;
    let minVM2 = null; let maxVM2 = null;
    let minSigma2 = null; let maxSigma2 = null;
    let minPM2 = null; let maxPM2 = null;
    let minStatisticDataT2 = null;  let maxStatisticDataT2 = null;
    let minL2 = null; let maxL2 = null;
    // Avg of all objects (sum and then avg)
    let sumVA1 = null; let avgVA1= null;
    let sumVM1 = null; let avgVM1= null;
    let sumVSigma1 = null; let avgSigma1= null;
    let sumPM1 = null; let avgPM1= null;
    let sumVA2 = null; let avgVA2= null;
    let sumVM2 = null; let avgVM2= null;
    let sumSigma2 = null; let avgSigma2= null;
    let sumPM2 = null; let avgPM2= null;
    let sumStatisticDataT2 = null; let avgStatisticDataT2= null;
    let sumL2 = null; let avgL2= null;

    this.csvRecords.forEach(data => {

      //this.csvRecords= this.csvRecords.filter(data => data.VA1 > fnum )

      minVA1 = (!minVA1 || minVA1 > parseFloat(data.VA1)) ? data.VA1 : minVA1;
      maxVA1 = (!maxVA1 || maxVA1 < parseFloat(data.VA1)) ? data.VA1 : maxVA1;
      sumVA1 = sumVA1 + parseFloat(data.VA1);
      avgVA1 = sumVA1/2000
      
      if (fnum > maxVA1) {
        minVA1=0;
        maxVA1=0;
        avgVA1=0;
     }


      minVM1 = (!minVM1 || minVM1 > parseFloat(data.VM1)) ? data.VM1 : minVM1;
      maxVM1 = (!maxVM1 || maxVM1 < parseFloat(data.VM1)) ? data.VM1 : maxVM1;
      sumVM1 = sumVM1 + parseFloat(data.VM1);
      avgVM1 = sumVM1/2000
      if (fnum > maxVM1) {
        minVM1=0;
        maxVM1=0;
        
      }

      minSigma1 = (!minSigma1 || minSigma1 > parseFloat(data.Sigma1)) ? data.Sigma1 : minSigma1;
      maxSigma1 = (!maxSigma1 || maxSigma1 < parseFloat(data.Sigma1)) ? data.Sigma1 : maxSigma1;
      sumVSigma1 = sumVSigma1 + parseFloat(data.Sigma1);
      avgSigma1 = sumVSigma1/2000
      if (fnum > maxSigma1) {
        minSigma1=0;
        maxSigma1=0;
       
      }


      minPM1 = (!minPM1 || minPM1 > parseFloat(data.PM1)) ? data.PM1 : minPM1;
      maxPM1 = (!maxPM1 || maxPM1 < parseFloat(data.PM1)) ? data.PM1 : maxPM1;
      sumPM1 = sumPM1 + parseFloat(data.PM1);
      avgPM1 = sumPM1/2000
      if (fnum > maxPM1) {
        minPM1=0;
        maxPM1=0;
        
      }

      minVA2 = (!minVA2 || minVA2 > parseFloat(data.VA2)) ? data.VA2 : minVA2;
      maxVA2 = (!maxVA2 || maxVA2 < parseFloat(data.VA2)) ? data.VA2 : maxVA2;
      sumVA2 = sumVA2 + parseFloat(data.VA2);
      avgVA2 = sumVA2/2000
      if (fnum > maxVA2) {
        minVA2=0;
        maxVA2=0;
       
      }


      minVM2 = (!minVM2 || minVM2 > parseFloat(data.VM2)) ? data.VM2 : minVM2;
      maxVM2 = (!maxVM2 || maxVM2 < parseFloat(data.VM2)) ? data.VM2 : maxVM2;
      sumVM2 = sumVM2 + parseFloat(data.VM2);
      avgVM2 = sumVM2/2000
      if (fnum > maxVM2) {
        minVM2=0;
        maxVM2=0;
       
      }

      minSigma2 = (!minSigma2 || minSigma2 > parseFloat(data.Sigma2)) ? data.Sigma2 : minSigma2;
      maxSigma2 = (!maxSigma2 || maxSigma2 < parseFloat(data.Sigma2)) ? data.Sigma2 : maxSigma2;
      sumSigma2 = sumSigma2 + parseFloat(data.Sigma2);
      avgSigma2 = sumSigma2/2000
      if (fnum > maxSigma2) {
        minSigma2=0;
        maxSigma2=0;
        
      }

      minPM2 = (!minPM2 || minPM2 > parseFloat(data.PM2)) ? data.PM2 : minPM2 ;
      maxPM2 = (!maxPM2 || maxPM2 < parseFloat(data.PM2)) ? data.PM2 : maxPM2 ;
      sumPM2 = sumPM2 + parseFloat(data.PM2);
      avgPM2 = sumPM2/2000
      if (fnum > maxPM2) {
        minPM2=0;
        maxPM2=0;
       
      }

      minStatisticDataT2 = (!minStatisticDataT2 || minStatisticDataT2 > parseFloat(data.StatisticDataT2)) ? data.StatisticDataT2 : minStatisticDataT2;
      maxStatisticDataT2 = (!maxStatisticDataT2 || maxStatisticDataT2 < parseFloat(data.StatisticDataT2)) ? data.StatisticDataT2 : maxStatisticDataT2;
      sumStatisticDataT2 = sumStatisticDataT2 + parseFloat(data.StatisticDataT2);
      avgStatisticDataT2 = sumStatisticDataT2/2000
      if (fnum > maxStatisticDataT2) {
        minStatisticDataT2=0;
        maxStatisticDataT2=0;
        
      }


      minL2 = (!minL2 || minL2 > parseFloat(data.L2) ) ? data.L2 : minL2;
      maxL2 = (!maxL2 || maxL2 < parseFloat(data.L2)) ? data.L2 : maxL2;
      sumL2 = sumL2 + parseFloat(data.L2);
      avgL2 = sumL2/2000
      if (fnum > maxL2) {
        minL2=0;
        maxL2=0;
        
      }

    }     
      );
      return {
              minVA1,minVM1,minSigma1,minPM1,minVA2,minVM2,minSigma2,minPM2,minStatisticDataT2,minL2,
             maxVA1,maxVM1,maxSigma1,maxPM1,maxVA2,maxVM2,maxSigma2,maxPM2,maxStatisticDataT2,maxL2,avgVA1,avgVM1,avgSigma1,
             avgPM1,avgVA2,avgVM2,avgSigma2,avgPM2,avgStatisticDataT2,avgL2
              }
    
    }

  displayedColumns: string[] = ['VA1', 'VM1', 'Sigma1', 'PM1','VA2','VM2','Sigma2','PM2','StatisticDataT2','L2'];
   dataSource = this.csvRecords;

 
}